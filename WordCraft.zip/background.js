
chrome.runtime.onInstalled.addListener(() => {
  console.log("WordCraft installed!");
});
