
document.getElementById("toggle").addEventListener("click", () => {
  alert("Toggling WordCraft functionality!");
});
