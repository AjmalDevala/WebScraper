
document.addEventListener("input", (event) => {
  if (event.target.nodeName === "TEXTAREA" || event.target.nodeName === "INPUT") {
    const text = event.target.value;
    // Call Grammar API (example)
    fetch("https://api.languagetool.org/v2/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: text,
        language: "en-US"
      })
    })
    .then(response => response.json())
    .then(data => {
      // Highlight errors in text (logic to be added)
      console.log(data);
    })
    .catch(error => console.error("Error checking grammar:", error));
  }
});
